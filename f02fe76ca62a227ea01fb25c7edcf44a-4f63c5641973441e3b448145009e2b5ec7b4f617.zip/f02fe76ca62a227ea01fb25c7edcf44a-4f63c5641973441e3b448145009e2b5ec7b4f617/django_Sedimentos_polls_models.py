from django.db import models
from django.utils.encoding import python_2_unicode_compatible
# Create your models here.
class Continente (models.Model):
    Nome=models.CharField(max_length=25)
    def __str__(self):
        return self.Nome

    Sigla = models.CharField(max_length=5)
    def __str__(self):
        return self.Sigla

    Amostra= models.CharField(max_length=10)
    def __str__(self):
        return self.Amostra



##########################################################################################################################
class País(models.Model):
    Nome= models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Amostra = models.CharField(max_length=10)
    def __str__(self):
        return self.Amostra

    Região=models.CharField(max_length=20)
    def __str__(self):
        return self.Região
    blank = True,
    null = True,

    Cidade=models.CharField(max_length=40)
    def __str__(self):
        return self.Cidade
    blank = True,
    null = True,

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,


Continentes = models.ManyToManyField(Continente)

#########################################################################################################################


class Estado(models.Model):
    Nome = models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    País = models.CharField(max_length=20)
    def __str__(self):
        return self.País

    Caracteristicas = models.CharField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Região = models.CharField(max_length=20)
    def __str__(self):
        return self.Região
    blank = True,
    null = True,

    Clima= models.CharField(max_length=200)
    def __str__(self):
        return self.Clima
    blank = True,
    null = True,

    Amostra = models.CharField(max_length=10)
    def __str__(self):
        return self.Amostra


Países=models.ManyToManyField(País)

############################################################################################################################

class Cidade(models.Model):
    Nome = models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Amostra = models.CharField(max_length=30)
    def __str__(self):
        return self.Amostra

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Região = models.CharField(max_length=20)
    def __str__(self):
        return self.Região
    blank = True,
    null = True,

    Geologia = models.TextField(max_length=600)
    def __str__(self):
        return self.Geologia
    blank = True,
    null = True,

    Clima = models.CharField(max_length=200)
    def __str__(self):
        return self.Clima
    blank = True,
    null = True,

Estados = models.ManyToManyField(Estado)
############################################################################################################################

class Clima(models.Model):
    Nome = models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Tipo= models.CharField(max_length=20)
    def __str__(self):
        return self.Tipo

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Cidades = models.ManyToManyField(Cidade)
#############################################################################################################################

class Subclima(models.Model):
    Nome=models.CharField(max_length=25)
    def __str__(self):
        return self.Nome
    blank = True,
    null = True,

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Climas=models.ManyToManyField(Clima)
#############################################################################################################################


class Coletador(models.Model):
    Nome=models.CharField(max_length=50)
    def __str__(self):
        return self.Coletador
    blank = True,
    null = True,

    Amostra = models.CharField(max_length=30)
    def __str__(self):
        return self.Amostra
    blank = True,
    null = True,

    País=models.CharField(max_length=20)
    def __str__(self):
        return self.País
    blank = True,
    null = True,



###########################################################################################################################

class Tipo(models.Model):
    Nome= models.CharField(max_length=15)
    def __str__(self):
        return self.Nome
    blank = True,
    null = True,
###########################################################################################################################

class Longitude(models.Model):
    Graus=models.CharField(max_length=15)
    def __str__(self):
        return self.Graus
    blank = True,
    null = True,

    Minutos=models.CharField(max_length=15)
    def __str__(self):
        return self.Minutos
    blank = True,
    null = True,

    Segundos=models.CharField(max_length=15)
    def __str__(self):
        return self.Segundos
    blank = True,
    null = True,

    UTM=models.CharField(max_length=15)
    def __str__(self):
        return self.UTM
    blank = True,
    null = True,
##################################################################################################################################################

class Latitude(models.Model):
    Graus = models.CharField(max_length=15)
    def __str__(self):
        return self.Graus
    blank = True,
    null = True,

    Minutos = models.CharField(max_length=15)
    def __str__(self):
         return self.Minutos
    blank = True,
    null = True,

    Segundos =models.CharField(max_length=15)
    def __str__(self):
         return self.Segundos
    blank = True,
    null = True,

    UTM =models.CharField(max_length=15)
    def __str__(self):
          return self.UTM
    blank = True,
    null = True,

###########################################################################################################################################################

class Amostra(models.Model):
    Codigo = models.CharField(max_length=10)
    def __str__(self):
        return self.Codigo

    Ambiente = models.CharField(max_length=30)
    def __str__(self):
        return self.Origem

   # Tipo= models.CharField(max_length=30)
   # def __str__(self):
    #    return self.Tipo

   # País= models.CharField(max_length=30)
   # def __str__(self):
   #2#     return self.País

   # Estado= models.CharField(max_length=30)
   # def __str__(self):
    #    return self.Estado

   # Longitude= models.CharField(max_length=30)
   # def __str__(self):
   #     return self.Longitude

    #Latitude= models.CharField(max_length=30)
   # def __str__(self):
   #     return self.Latitude

    Descrição = models.TextField(max_length=500)
    def __str__(self):
        return self.Descrição

    Granolumetria =models.CharField(max_length=15)
    def __str__(self):
        return self.Granolumetria

    Data= models.CharField(max_length=15)
    def __str__(self):
        return self.Data
    blank = True,
    null = True,

Continentes = models.ManyToManyField(Continente)
Países = models.ManyToManyField(País)
Estados = models.ManyToManyField(Estado)
Cidades = models.ManyToManyField(Cidade)
Tipos = models.ManyToManyField(Tipo)
Longitudes = models.ManyToManyField(Longitude)
Latitudes = models.ManyToManyField(Latitude)
Coletadores = models.ManyToManyField(Coletador)
###############################################################################################################################