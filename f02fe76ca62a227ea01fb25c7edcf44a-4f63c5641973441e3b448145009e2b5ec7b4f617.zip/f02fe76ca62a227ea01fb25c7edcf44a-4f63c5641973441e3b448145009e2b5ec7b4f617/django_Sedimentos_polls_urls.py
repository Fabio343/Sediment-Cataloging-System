from django.conf.urls import url

from . import views

app_name = 'polls'

urlpatterns = [
   # url(r'^$', views.index, name='index'),
url(r'^(?P<amostra_Tipo>[0-9]+)/$', views.Amostra, name='Tipo'),
url(r'^(?P<amostra_Codigo>[0-9]+)/$', views.Amostra, name='Codigo'),
url(r'^(?P<amostra_Ambiente>[0-9]+)/$', views.Amostra, name='Ambiente'),
url(r'^(?P<amostra_Granulometria>[0-9]+)/$', views.Amostra, name='Granulometria'),
url(r'^(?P<amostra_País>[0-9]+)/$', views.Amostra, name='País'),
url(r'^(?P<amostra_Cidade>[0-9]+)/$', views.Amostra, name='Cidade'),
url(r'^(?P<amostra_Estado>[0-9]+)/$', views.Amostra, name='Estado'),
url(r'^(?P<amostra_Continente>[0-9]+)/$', views.Amostra, name='Continente'),
url(r'^(?P<amostra_Longitude>[0-9]+)/$', views.Amostra, name='Longitude'),
url(r'^(?P<amostra_Latitude>[0-9]+)/$', views.Amostra, name=' Latitude'),
url(r'^(?P<amostra_Coletador>[0-9]+)/$', views.Amostra, name='Coletador'),

    #url(r'^(?P<amostra_id>[0-9]+)/tipo/$', views.tipo),

]