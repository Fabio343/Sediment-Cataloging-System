#from django.shortcuts import render

# Create your views here.
# Create your views here.
from django.http import HttpResponse, HttpResponseNotFound
#from django.template import loader
from django.http import Http404
#from django.shortcuts import get_object_or_404, render
from .models import Amostra

def Tipo_amostra(request):
    Tipo = Amostra.Amostra.Tipo()
    html= "<html><Tipo De Amostra %s.</body></html>" %Tipo
    return HttpResponse(html)

def Codigo_amostra(request):
    Codigo = Amostra.Amostra.Codigo()
    html= "<html><Codigo Da Amostra %s.</body></html>" %Codigo
    return HttpResponse(html)


def Ambiente_amostra(request):
    Ambiente = Amostra.Amostra.Ambiente()
    html= "<html><Ambiente Da Amostra %s.</body></html>" %Ambiente
    return HttpResponse(html)


def Granulometria_amostra(request):
    Granulometria = Amostra.Amostra. Granulometria()
    html= "<html>< Granulometria Da Amostra %s.</body></html>" %Granulometria
    return HttpResponse(html)


def País_amostra(request):
    País = Amostra.Amostra.País()
    html= "<html><País Da Amostra %s.</body></html>" %País
    return HttpResponse(html)


def Cidade_amostra(request):
    Cidade = Amostra.Amostra.Cidade()
    html= "<html><Cidade Da Amostra %s.</body></html>" %Cidade
    return HttpResponse(html)

def Estado_amostra(request):
    Estado = Amostra.Amostra.Estado()
    html= "<html><Estado Da Amostra %s.</body></html>" %Estado
    return HttpResponse(html)

def Continente_amostra(request):
    Continente = Amostra.Amostra.Continente()
    html= "<html><Continente Da Amostra %s.</body></html>" %Continente
    return HttpResponse(html)

def Longitude_amostra(request):
    Longitude = Amostra.Amostra.Longitude()
    html= "<html><Longitude Da Amostra %s.</body></html>" %Longitude
    return HttpResponse(html)

def Latitude_amostra(request):
    Latitude = Amostra.Amostra.Latitude()
    html= "<html><Latitude Da Amostra %s.</body></html>" %Latitude
    return HttpResponse(html)

def Coletador_amostra(request):
    Coletador = Amostra.Amostra.Longitude()
    html= "<html><Coletador Da Amostra %s.</body></html>" %Coletador
    return HttpResponse(html)
