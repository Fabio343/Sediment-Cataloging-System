from django.conf.urls import url

from . import views
from django.conf.urls import url

from . import views

app_name = 'polls'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^(?P<amostra_id>[0-9]+)/$', views.detail, name='detail'),
   # url(r'^(?P<amostra_id>[0-9]+)/tipo/$', views.tipo, name='tipo'),

]