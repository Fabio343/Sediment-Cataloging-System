from django.shortcuts import render

# Create your views here.
# Create your views here.
from django.http import HttpResponse
from django.http import HttpResponse
from django.template import loader
from django.http import Http404
from django.shortcuts import get_object_or_404, render

from .models import Amostra
#######################################################################
def index(request):
    latest_amostra_list=Amostra.objects.order_by('id')
    template = loader.get_template('polls/index.html')
    context = {
    'latest_amostra_list': latest_amostra_list,
    }
    return HttpResponse(template.render(context, request))
######################################################################
def detail(request, amostra_id):
    try:
        amostra = Amostra.objects.get(pk=Amostra_id)
    except Amostra.DoesNotExist:
        raise Http404("Amostra não catalogada ou não existe")
    return render(request, 'polls/detail.html', {'amostra': amostra})
######################################################################
def detail(request, amostra_id):
    amostra = get_object_or_404(amostra, pk=amostra_id)
    return render(request, 'polls/detail.html', {'amostra': amostra})

#def index(request):
  #  return HttpResponse("Olá seja Bem Vindo ao Nosso Sistema de Banco de Dados de Catalogação de Sedimentos")
########################################################################
def amostra(request):
    latest_amostra_list = Amostra.objects.order_by('id')
    template = loader.get_template('polls/index.html')
    context = {
        'latest_amostra_list': latest_amostra_list,
    }
    return HttpResponse(template.render(context, request))
######################################################################
def amostra(request, amostra_id):
    try:
        amostra = Amostra.objects.get(pk=Amostra_id)
    except Amostra.DoesNotExist:
        raise Http404("Amostra não catalogada ou não existe")
    return render(request, 'polls/detail.html', {'amostra': amostra})
######################################################################
def amostra(request, amostra_id):
    amostra = get_object_or_404(amostra, pk=amostra_id)
    return render(request, 'polls/detail.html', {'amostra': amostra})
#######################################################################
