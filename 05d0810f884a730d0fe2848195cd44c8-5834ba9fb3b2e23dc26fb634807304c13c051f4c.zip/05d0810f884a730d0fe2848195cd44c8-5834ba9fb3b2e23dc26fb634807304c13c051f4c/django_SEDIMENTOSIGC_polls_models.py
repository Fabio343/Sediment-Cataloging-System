from django.db import models
from django.utils.encoding import python_2_unicode_compatible

# Create your models here.
class ContinenteQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Codigo_Amostra(self):
         return self.filter(role='A')

class ContinenteManager(models.Manager):
    def get_queryset(self):
       return AmostraQuerySet (self.model,using=self._db)
    def Nome(self):
        return self.get_queryset().Nome()
    def Codigo(self):
        return self.get_queryset().Codigo_Amostra()

class Continente (models.Model):
    Nome=models.CharField(max_length=25)
    def __str__(self):
        return self.Nome

    Sigla = models.CharField(max_length=5)
    def __str__(self):
        return self.Sigla

    Codigo_Amostra= models.CharField(max_length=10)
    def __str__(self):
        return self.Amostra

    role= models.CharField(max_length=10, choices=(('A',('Nome')),('A',('Codigo'))))
    Continente=ContinenteManager()

########################################################################################################################
########################################################################################################################
class PaisQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Codigo_Amostra(self):
        return self.filter(role='A')

    def Cidade(self):
        return self.filter(role='A')


class PaisManager(models.Manager):
   def get_queryset(self):
       return PaisQuerySet( self.model,using=self._db)

   def Nome(self):
       return self.get_queryset().Nome()

   def Codigo_Amostra(self):
        return self.get_queryset().Codigo_Amostra()

   def Cidade(self):
        return self.get_queryset().Cidade()

class País(models.Model):
    Nome= models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Codigo_Amostra = models.CharField(max_length=10)
    def __str__(self):
        return self.Amostra

    Região=models.CharField(max_length=20)
    def __str__(self):
        return self.Região
    blank = True,
    null = True,

    Cidade=models.CharField(max_length=40)
    def __str__(self):
        return self.Cidade
    blank = True,
    null = True,

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,


    Continentes = models.ManyToManyField(Continente)


role = models.CharField(max_length=10, choices=(('A', ('Nome')),('A',('Codigo_Amostra')),(('A',('Cidade')))))
Pais = PaisManager()

########################################################################################################################
########################################################################################################################
class EstadoQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Codigo_Amostra(self):
        return self.filter(role='A')

class EstadoManager(models.Manager):
    def get_queryset(self):
        return EstadoQuerySet(self.model, using=self._db)

    def Nome(self):
        return self.get_queryset().Nome()

    def Codigo_Amostra(self):
        return self.get_queryset().Codigo_Amostra()

class Estado(models.Model):
    Nome = models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Caracteristicas = models.CharField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Região = models.CharField(max_length=20)
    def __str__(self):
        return self.Região
    blank = True,
    null = True,

    Clima= models.CharField(max_length=200)
    def __str__(self):
        return self.Clima
    blank = True,
    null = True,

    Codigo_Amostra = models.CharField(max_length=10)
    def __str__(self):
        return self.Amostra


    Paíss=models.ManyToManyField(País)

    role = models.CharField(max_length=10, choices=(('A', ('Nome')),('A',('Codigo_Amostra'))))
    Estado = EstadoManager()


########################################################################################################################
########################################################################################################################
class CidadeQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Codigo_Amostra(self):
        return self.filter(role='A')

class CidadeManager(models.Manager):
    def get_queryset(self):
        return CidadeQuerySet(self.model, using=self._db)

    def Nome(self):
        return self.get_queryset().Nome()

    def Codigo_Amostra(self):
        return self.get_queryset().Codigo_Amostra()

class Cidade(models.Model):
    Nome = models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Codigo_Amostra = models.CharField(max_length=30)
    def __str__(self):
        return self.Amostra

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Região = models.CharField(max_length=20)
    def __str__(self):
        return self.Região
    blank = True,
    null = True,

    Geologia = models.TextField(max_length=600)
    def __str__(self):
        return self.Geologia
    blank = True,
    null = True,

    Clima = models.CharField(max_length=200)
    def __str__(self):
        return self.Clima
    blank = True,
    null = True,

    Estados = models.ManyToManyField(Estado)

    role = models.CharField(max_length=10, choices=(('A', ('Nome')),('A',('Codigo_Amostra'))))
    Cidade = CidadeManager()
########################################################################################################################
########################################################################################################################
class ClimaQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Tipo(self):
        return self.filter(role='A')

class ClimaManager(models.Manager):
    def get_queryset(self):
        return ClimaQuerySet(self.model, using=self._db)

    def Nome(self):
        return self.get_queryset().Nome()

    def Tipo(self):
        return self.get_queryset().Tipo()


class Clima(models.Model):
    Nome = models.CharField(max_length=20)
    def __str__(self):
        return self.Nome

    Tipo= models.CharField(max_length=20)
    def __str__(self):
        return self.Tipo

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Cidades = models.ManyToManyField(Cidade)

    role = models.CharField(max_length=10, choices=(('A', ('Nome')),('A',('Tipo'))))
    Clima = ClimaManager()
########################################################################################################################
########################################################################################################################
class SubclimaQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Tipo(self):
        return self.filter(role='A')

class SubclimaManager(models.Manager):
    def get_queryset(self):
        return SubclimaQuerySet(self.model, using=self._db)

    def Nome(self):
        return self.get_queryset().Nome()
    def id(self):
        return self.get_queryset().id()

class Subclima(models.Model):
    Nome=models.CharField(max_length=25)
    def __str__(self):
        return self.Nome
    blank = True,
    null = True,

    Caracteristicas = models.TextField(max_length=500)
    def __str__(self):
        return self.Caracteristicas
    blank = True,
    null = True,

    Climas=models.ManyToManyField(Clima)

    role = models.CharField(max_length=10,choices=(('A',('Nome')),('1',('id'))))
    Subclima = SubclimaManager()
########################################################################################################################
########################################################################################################################
class ColetadorQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

    def Codigo_Amostra(self):
        return self.filter(role='A')

class ColetadorManager(models.Manager):
    def get_queryset(self):
        return ColetadorQuerySet(self.model, using=self._db)

    def Nome(self):
        return self.get_queryset().Nome()

    def Codigo_Amostra(self):
        return self.get_queryset().Codigo_Amostra()

class Coletador(models.Model):
    Nome=models.CharField(max_length=50)
    def __str__(self):
        return self.Coletador
    blank = True,
    null = True,

    Codigo_Amostra = models.CharField(max_length=30)
    def __str__(self):
        return self.Amostra
    blank = True,
    null = True,

    Paíss = models.ManyToManyField(País)

    role = models.CharField(max_length=10, choices=(('A', ('Nome')),('A',('Codigo_Amostra'))))
    Coletador = ColetadorManager()
########################################################################################################################
########################################################################################################################
class TipoQuerySet(models.QuerySet):
    def Nome(self):
        return self.filter(role='A')

class TipoManager(models.Manager):
    def get_queryset(self):
        return TipoQuerySet(self.model, using=self._db)

    def Nome(self):
        return self.get_queryset().Nome()

    def id(self):
        return self.get_queryset().id()

class Tipo(models.Model):
    Nome= models.CharField(max_length=15)
    def __str__(self):
        return self.Nome
    blank = True,
    null = True,
    role = models.CharField(max_length=10, choices=(('A', ('Nome')),('1',('id'))))
    Tipo = TipoManager()
########################################################################################################################
########################################################################################################################

class Longitude(models.Model):
    Graus=models.DecimalField(max_digits=5,decimal_places=2)
    def __str__(self):
        return self.Graus
    blank = True,
    null = True,

    Minutos=models.DecimalField(max_digits=5,decimal_places=2)
    def __str__(self):
        return self.Minutos
    blank = True,
    null = True,

    Segundos=models.DecimalField(max_digits=5, decimal_places=2)
    def __str__(self):
        return self.Segundos
    blank = True,
    null = True,

    UTM=models.DecimalField(max_digits=8,decimal_places=3)
    def __str__(self):
        return self.UTM
    blank = True,
    null = True,
########################################################################################################################
########################################################################################################################

class Latitude(models.Model):
    Graus = models.DecimalField(max_digits=5, decimal_places=2)
    def __str__(self):
        return self.Graus
    blank = True,
    null = True,

    Minutos = models.DecimalField(max_digits=5, decimal_places=2)
    def __str__(self):
         return self.Minutos
    blank = True,
    null = True,

    Segundos = models.DecimalField(max_digits=5, decimal_places=2)
    def __str__(self):
         return self.Segundos
    blank = True,
    null = True,

    UTM = models.DecimalField(max_digits=8, decimal_places=3)
    def __str__(self):
          return self.UTM
    blank = True,
    null = True,
########################################################################################################################
########################################################################################################################

class AmostraQuerySet(models.QuerySet):

    def Codigo_Amostra(self):
        return self.filter(role='A')

    def Ambiente(self):
        return self.filter(role='A')

    def Granulometria(self):
        return self.filter(role='A')

class AmostraManager(models.Manager):
   def get_queryset(self):
       return AmostraQuerySet( self.model,using=self._db)

   def Codigo_Amostra(self):
        return self.get_queryset().Codigo_Amostra()

   def Ambiente(self):
        return self.get_queryset().Ambiente()
   def Granulometeria(self):
       return self.get_queryset().Granulometria()


class Amostra(models.Model):
    Codigo_Amostra = models.CharField(max_length=10)
    def __str__(self):
        return self.Codigo

    Ambiente = models.CharField(max_length=30)
    def __str__(self):
        return self.Origem

    Descrição = models.TextField(max_length=500)
    def __str__(self):
        return self.Descrição

    Granolumetria =models.DecimalField (max_digits =12,decimal_places=7)
    def __str__(self):
        return self.Granolumetria

    Data= models.CharField(max_length=15)
    def __str__(self):
        return self.Data
    blank = True,
    null = True,



    Continentes = models.ManyToManyField(Continente)
    Paíss = models.ManyToManyField(País)
    Estados = models.ManyToManyField(Estado)
    Cidades = models.ManyToManyField(Cidade)
    Tipos = models.ManyToManyField(Tipo)
    Coletadors = models.ManyToManyField(Coletador)
    Longitudes = models.ManyToManyField(Longitude)
    Latitudes = models.ManyToManyField(Latitude)



    role = models.CharField(max_length=10, choices=(('A', ('Codigo_Amostra')),('A',('Ambiente')),(('A',('Granulometria')))))
    Amostra = AmostraManager()
########################################################################################################################
########################################################################################################################