from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

#def index(request):
    #return HttpResponse("Hello, world. You're at the polls index.")




########################################################################################################################
def Codigo_Amostra(request):
    html = "<html><Codigo_Amostra>%s.</Codigo_Amostra></html>"
    return HttpResponse(html)

def Tipo(request):
    html = "<html><Tipo>%s.</Tipo></html>"
    return HttpResponse(html)

def Ambiente(request):
   html = "<html><Ambiente>%s.</Ambiente></html>"
   return HttpResponse(html)

def Granulometria(request):
   html = "<html><Granulometria>%s.</Granulometria></html>"
   return HttpResponse(html)

def Descrição(request):
   html = "<html><Descrição>%s.</Descrição></html>"
   return HttpResponse(html)

def País(request):
   html = "<html><País>%s.</País></html>"
   return HttpResponse(html)

def Estado(request):
   html = "<html><Estado>%s.</Estado></html>"
   return HttpResponse(html)

def Cidade(request):
   html = "<html><Cidade>%s.</Cidade></html>"
   return HttpResponse(html)

def Longitude(request):
   html = "<html><Graus><html><Minutos><html><Segundos><html><UTM>%s.</Longitude></html>"
   return HttpResponse(html)

def Latitude(request):
   html = "<html><Graus><html><Minutos><html><Segundos><html><UTM>%s.</Latitude></html>"
   return HttpResponse(html)

def Coletador(request):
   html = "<html><Coletador>%s.</Coletador></html>"
   return HttpResponse(html)

def Data(request):
   html = "<html><Data>%s.</Data></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Graus(request):
   html = "<html><Graus>%s.</Graus></html>"
   return HttpResponse(html)

def Minutos(request):
   html = "<html><Minutos>%s.</Minutos></html>"
   return HttpResponse(html)

def Segundos(request):
   html = "<html><Segundos>%s.</Segundos></html>"
   return HttpResponse(html)

def UTM(request):
   html = "<html><UTM>%s.</UTM></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Graus(request):
   html = "<html><Graus>%s.</Graus></html>"
   return HttpResponse(html)

def Minutos(request):
   html = "<html><Minutos>%s.</Minutos></html>"
   return HttpResponse(html)

def Segundos(request):
   html = "<html><Segundos>%s.</Segundos></html>"
   return HttpResponse(html)

def UTM(request):
   html = "<html><UTM>%s.</UTM></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Nome(request):
   html = "<html><Nome>%s.</Nome></html>"
   return HttpResponse(html)

def Codigo_Amostra(request):
   html = "<html><Codigo_Amostra>%s.</Codigo_Amostra></html>"
   return HttpResponse(html)

def Caracteristicas(request):
   html = "<html><Caracteristicas>%s.</Caracteristicas></html>"
   return HttpResponse(html)

def Clima(request):
   html = "<html><Clima>%s.</Clima></html>"
   return HttpResponse(html)

def Região(request):
   html = "<html><região>%s.</Região></html>"
   return HttpResponse(html)


def Geologia(request):
   html = "<html><Geologia>%s.</Geologia></html>"
   return HttpResponse(html)

def Estado(request):
   html = "<html><Continente><html><País><html><Estado>%s.</Estado></html>"
   return HttpResponse(html)

def País(request):
   html = "<html><Continente><html><País>%s.</País></html>"
   return HttpResponse(html)

def Continente(request):
   html = "<html><Continente>%s.</Continente></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Nome(request):
   html = "<html><Nome>%s.</Nome></html>"
   return HttpResponse(html)

def Codigo_Amostra(request):
   html = "<html><Codigo_Amostra>%s.</Codigo_Amostra></html>"
   return HttpResponse(html)

def Caracteristicas(request):
   html = "<html><Caracteristicas>%s.</Caacteristicas></html>"
   return HttpResponse(html)

def Cidade(request):
   html = "<html><Continente><html><País><html><Estado><html><Cidade>%s.</Cidade></html>"
   return HttpResponse(html)

def Região(request):
   html = "<html><Região>%s.</Região></html>"
   return HttpResponse(html)

def Continente(request):
   html = "<html><Continente>%s.</Continente></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Nome(request):
   html = "<html><Nome>%s.</Nome></html>"
   return HttpResponse(html)

def Codigo_Amostra(request):
   html = "<html><Codigo_Amostra>%s.</Codigo_Amostra></html>"
   return HttpResponse(html)

def Sigla(request):
   html = "<html><Sigla>%s.</Sigla></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Nome(request):
   html = "<html><Nome>%s.</Nome></html>"
   return HttpResponse(html)

def Codigo_Amostra(request):
   html = "<html><Codigo_Amostra>%s.</Codigo_Amostra></html>"
   return HttpResponse(html)

def Estado(request):
   html = "<html><Continente><html><País><html><Codigo_Amostra><html><Estado>%s.</Estado></html>"
   return HttpResponse(html)

def País(request):
   html = "<html><Continente><html><País>%s.</País></html>"
   return HttpResponse(html)

def Continente(request):
   html = "<html><Continente>%s.</Continente></html>"
   return HttpResponse(html)

def Cidade(request):
   html = "<html><Continente><html><País><html><Estado><html><Cidade>%s.</Cidade></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Nome(request):
   html = "<html><Nome>%s.</Nome></html>"
   return HttpResponse(html)

def Tipo(request):
   html = "<html><Nome><html><Tipo>%s.</Tipo></html>"
   return HttpResponse(html)

def Caracteristicas(request):
   html = "<html><Caracteristicas>%s.</Caracteristicas></html>"
   return HttpResponse(html)

def Cidade(request):
   html = "<html><Continente><html><País><html><Estado><html><Cidade>%s.</Cidade></html>"
   return HttpResponse(html)

def Subclima(request):
   html = "<html><Subclima>%s.</Subclima></html>"
   return HttpResponse(html)

##################################################################################################################################################################################
def Nome(request):
   html = "<html><Nome>%s.</Nome></html>"
   return HttpResponse(html)

def Caacteristicas(request):
   html = "<html><Caracteristicas>%s.</Caracteristicas></html>"
   return HttpResponse(html)

def Clima(request):
   html = "<html><Clima>%s.</Clima></html>"
   return HttpResponse(html)
