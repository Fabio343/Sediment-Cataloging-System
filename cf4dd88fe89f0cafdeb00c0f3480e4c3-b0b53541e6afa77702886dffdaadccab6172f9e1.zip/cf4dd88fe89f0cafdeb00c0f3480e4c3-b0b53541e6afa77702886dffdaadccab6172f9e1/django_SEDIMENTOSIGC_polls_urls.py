from django.conf.urls import include, url
from . import views

urlpatterns = [
     url('r^Amostra/(?P<Codigo_Amostra>[0-9])/$',views.Codigo_Amostra),
     url('r^Amostra/(?P<Tipo>[0-9])/$',views.Tipo),
     url('r^Amostra/(?P<Ambiente>[0-9])/$',views.Ambiente),
     url('r^Amostra/([0-9]{4})/$',views.Granulometria),
     url('r^Amostra/(?P<Descrição>[0-9])/$',views.Descrição),
     url('r^Amostra/(?P<País>[0-9])/$',views.País),
     url('r^Amostra/(?P<Estado>[0-9])/$',views.Estado),
     url('r^Amostra/(?P<Cidade>[0-9])/$',views.Cidade),
     url('r^Amostra/(?P<Graus>[0-9]{3})/(?P<Minutos>[0-9]{3})/(?P<Segundos>[0-9]{3})/(?P<UTM>[0-9]{4})/$',views.Longitude),
     url('r^Amostra/(?P<Graus>[0-9]{3})/(?P<Minutos>[0-9]{3})/(?P<Segundos>[0-9]{3})/(?P<UTM>[0-9]{4})/$',views.Latitude),
     url('r^Amostra/(?P<Coletador>[0-9])/$',views.Coletador),
     url('r^Amostra/([0-9]{9})/$',views.Data),



     url('r^Latitude/([0-9]{3})/$',views.Graus),
     url('r^Latitude/([0-9]{3})/$',views.Minutos),
     url('r^Latitude/([0-9]{3})/$',views.Segundos),
     url('r^Latitude/([0-9]{4})/$',views.UTM),



     url('r^Longetude/([0-9]{3})/$', views.Graus),
     url('r^Longetude/([0-9]{3})/$', views.Minutos),
     url('r^Longetude/([0-9]{3})/$', views.Segundos),
     url('r^Longetude/([0-9]{4})/$', views.UTM),

     url('r^Cidades/(?P<Cidade>[0-9])/$',views.Nome),
     url('r^Cidades/(?P<Codigo_Amostra>[ [0-9])/$',views.Codigo_Amostra),
     url('r^Cidades/(?P<Caracteristicas>[0-9])/$',views.Caracteristicas),
     url('r^Cidades/(?P<Clima>[0-9])/$',views.Clima),
     url('r^Cidades/(?P<Região>[0-9])/$',views.Região),
     url('r^Cidades/(?P<Geologia>[0-9])/$', views.Geologia),
     url('r^Cidades/(?P<Continente>[0-9])/(?P<País>[0-9])/(?P<Estado>[0-9])/$', views.Estado),
     url('r^Cidades/(?P<Continente>[0-9])/(?P<País>[0-9])/$', views.País),
     url('r^Cidades/(?P<Continente>[0-9])/$', views.Continente),

     url('r^Estado/(?P<Nome>[0-9])/$',views.Nome),
     url('r^Estado/(?P<Codigo_Amostra>[0-9])/$',views.Codigo_Amostra),
     url('r^Estado/(?P<Caracteristicas>[0-9])/$',views.Caracteristicas),
     url('r^Estado/(?P<Clima>[0-9])/$',views.Clima),
     url('r^Estado/(?P<Continente>[0-9])/(?P<País>[0-9])/$', views.País),
     url('r^Estado/(?P<Região>[0-9])/$', views.Região),

     url('r^País/(?P<Nome>[0-9])/$',views.Nome),
     url('r^País/(?P<Codigo_Amostra>[0-9])/$',views.Codigo_Amostra),
     url('r^País/(?P<Caracteristicas>[0-9])/$',views.Caracteristicas),
     url('r^País/(?P<Continente>[0-9])/(?P<País>[0-9])/(?P<Estado>[0-9])/(?P<Cidade>[0-9])/$',views.Cidade),
     url('r^Cidades/(?P<Região>[0-9])/$',views.Região),
     url('r^Cidades/(?P<Continente>[0-9])/$', views.Continente),

     url('r^Continente/(?P<Nome>[0-9])/$',views.Nome),
     url('r^Continente/(?P<Codigo_Amostra>[0-9])/$',views.Codigo_Amostra),
     url('r^Continente/(?P<Sigla>[0-9])/$',views.Sigla),

     url('r^Coletador/(?P<Nome>[0-9])/$',views.Nome),
     url('r^Coletador/(?P<Codigo_Amostra>[0-9])/$',views.Codigo_Amostra),
     url('r^Coletador/(?P<Continente>[0-9])/(?P<País>[0-9])/(?P<Codigo>[0-9])/$', views.Estado),
     url('r^Coletador/(?P<Continente>[0-9])/(?P<País>[0-9])/$', views.País),
     url('r^Coletador/(?P<Continente>[0-9])/$', views.Continente),
     url('r^Coletador/(?P<Continente>[0-9])/(?P<País>[0-9])/(?P<estado>[0-9])/(?P<Cidade>[0-9])/$',views.Cidade),

     url('r^Clima/(?P<Nome>[0-9])/$',views.Nome),
     url('r^Clima/(?P<Nome>[0-9])/(?P<Tipo>[0-9])/$',views.Tipo),
     url('r^Clima/(?P<Caracteristicas>[0-9])/$',views.Caracteristicas),
     url('r^Clima/(?P<Continente>[0-9])/(?P<País>[0-9])/(?P<Estado>[0-9])/(?P<Cidade>[0-9])/$',views.Cidade),
     url('r^Clima/(?P<Subclima>[0-9])/$', views.Subclima),

     url('r^Subclima/(?P<Nome>[0-9])/$', views.Nome),
     url('r^Subclima/(?P<Caracteristicas>[0-9])/$', views.Caracteristicas),
     url('r^Subclima/(?P<Clima>[0-9])/$', views.Clima),

     #url(r'^$', views.index, name='index'),
]