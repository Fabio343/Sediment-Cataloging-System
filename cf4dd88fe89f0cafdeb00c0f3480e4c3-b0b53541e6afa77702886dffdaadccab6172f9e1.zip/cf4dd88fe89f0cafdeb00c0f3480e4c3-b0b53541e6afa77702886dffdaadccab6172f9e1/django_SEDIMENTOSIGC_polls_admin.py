from django.contrib import admin

# Register your models here.
############################################
from .models import Continente
admin.site.register(Continente)

############################################
from .models import País
admin.site.register(País)

############################################
from .models import Estado
admin.site.register(Estado)

############################################
from .models import Cidade
admin.site.register(Cidade)

###########################################
from .models import Clima
admin.site.register(Clima)

###########################################
from .models import Subclima
admin.site.register(Subclima)

###########################################
from  .models import Coletador
admin.site.register(Coletador)

###########################################
from .models import Amostra
admin.site.register(Amostra)

###########################################
from .models import  (Tipo)
admin.site.register(Tipo)

###########################################
from .models import  (Latitude)
admin.site.register(Latitude)

###########################################
from .models import  (Longitude)
admin.site.register(Longitude)
